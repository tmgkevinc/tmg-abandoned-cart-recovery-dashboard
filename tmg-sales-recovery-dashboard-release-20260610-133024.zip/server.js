const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");

loadEnv(path.join(ROOT, ".env"));

const PORT = Number(process.env.PORT || 8080);
const HOST = process.env.HOST || "0.0.0.0";
const ASSIGNMENTS_FILE = process.env.ASSIGNMENTS_FILE || path.join(ROOT, "lead-assignments.json");
const DATA_HUB_BASE_URL = String(process.env.TMG_DATA_HUB_BASE_URL || "").replace(/\/+$/, "");
const DATA_HUB_API_KEY =
  process.env.TEAM_API_KEY_DASHBOARD_EDITOR ||
  process.env.TEAM_API_KEY_ADMIN ||
  process.env.TMG_DATA_HUB_API_KEY ||
  "";
const DATA_HUB_KEY_TYPE = process.env.TEAM_API_KEY_DASHBOARD_EDITOR
  ? "dashboard_editor"
  : process.env.TEAM_API_KEY_ADMIN
    ? "admin"
    : process.env.TMG_DATA_HUB_API_KEY
      ? "read_only"
      : "missing";
const AUTH_MODE = normalizeAuthMode(process.env.DASHBOARD_AUTH_MODE || process.env.AUTH_MODE || "manual");
const ADMIN_EMAILS = parseEmailSet(process.env.ADMIN_EMAILS);
const SALES_EMAIL_MAP = parseSalesEmailMap(process.env.SALES_EMAIL_MAP);
const DATA_HUB_ASSIGNMENTS_WRITE_PATH = text(process.env.DATA_HUB_ASSIGNMENTS_WRITE_PATH || "");

const SALES_USERS = [
  "Johnny",
  "Brian",
  "Adam",
  "Josh",
  "Steven",
  "Arsenio",
  "Michael",
  "Non-sales",
];

const COUNTRY_META = {
  US: { currency: "USD", theme: "blue", siteBaseUrl: "https://www.tmgindustrial.com" },
  CA: { currency: "CAD", theme: "yellow", siteBaseUrl: "https://www.tmgindustrial.ca" },
  AU: { currency: "AUD", theme: "purple", siteBaseUrl: "https://www.tmgindustrial.com.au" },
};

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const session = getDashboardSession(req);

    if (url.pathname === "/api/session") {
      return sendJson(res, 200, session);
    }

    if (AUTH_MODE === "cloudflare_access" && url.pathname.startsWith("/api/") && !session.authenticated) {
      return sendJson(res, 403, {
        error: "Cloudflare Access email is required for this dashboard.",
        session,
      });
    }

    if (url.pathname === "/api/health") {
      return sendJson(res, 200, {
        authMode: AUTH_MODE,
        cloudflareAccessEnabled: AUTH_MODE === "cloudflare_access",
        currentUser: session.authenticated ? { email: session.email, user: session.user, role: session.role } : null,
        dataHubConfigured: Boolean(DATA_HUB_BASE_URL && DATA_HUB_API_KEY),
        dataHubBaseUrl: DATA_HUB_BASE_URL || null,
        dataHubKeyType: DATA_HUB_KEY_TYPE,
        dataHubUsesAdminKey: DATA_HUB_KEY_TYPE === "admin",
        dataHubUsesDashboardEditorKey: DATA_HUB_KEY_TYPE === "dashboard_editor",
        dataHubWriteCredential: DATA_HUB_KEY_TYPE === "dashboard_editor",
        markets: Object.keys(COUNTRY_META),
        salesUsers: SALES_USERS,
        persistence: DATA_HUB_ASSIGNMENTS_WRITE_PATH ? "data-hub-and-local-json" : "local-json",
        writeAccess: Boolean(DATA_HUB_ASSIGNMENTS_WRITE_PATH),
        assignmentWritePathConfigured: Boolean(DATA_HUB_ASSIGNMENTS_WRITE_PATH),
      });
    }

    if (url.pathname === "/api/data-hub/catalog") {
      return await proxyDataHub(res, "/api/data-hub/catalog");
    }

    if (url.pathname === "/api/data-hub/freshness") {
      return await proxyDataHub(res, "/api/data-hub/freshness");
    }

    if (url.pathname === "/api/leads") {
      return await handleLeads(url, res);
    }

    if (url.pathname === "/api/assignments" && req.method === "GET") {
      return sendJson(res, 200, readAssignments());
    }

    if (url.pathname === "/api/assignments" && req.method === "POST") {
      return await handleSaveAssignment(req, res);
    }

    return serveStatic(url.pathname, res);
  } catch (error) {
    console.error(error);
    return sendJson(res, 500, { error: "An unknown server error occurred." });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Dashboard ready: http://${HOST}:${PORT}`);
});

async function handleLeads(url, res) {
  if (!DATA_HUB_BASE_URL || !DATA_HUB_API_KEY) {
    return sendJson(res, 400, {
      error: "Set TMG_DATA_HUB_BASE_URL and TMG_DATA_HUB_API_KEY in .env before loading leads.",
    });
  }

  const markets = String(url.searchParams.get("market") || "US,CA,AU")
    .split(",")
    .map((market) => market.trim().toUpperCase())
    .filter((market) => COUNTRY_META[market]);
  const limit = Math.max(25, Math.min(Number(url.searchParams.get("limit") || 5000), 10000));
  const includeKlaviyo = url.searchParams.get("klaviyo") === "1";
  const useEnriched = url.searchParams.get("source") !== "raw";

  const startedAt = new Date();
  const checkoutResults = await Promise.all(markets.map(async (market) => {
    const records = await fetchAbandonedCartLeads(market, limit, useEnriched ? "enriched" : "raw");
    return {
      market,
      records,
    };
  }));

  const productLookup = useEnriched ? {} : await buildProductLookupFromCheckouts(checkoutResults);
  const klaviyoProfiles = useEnriched || !includeKlaviyo ? [] : await buildKlaviyoProfilesFromCheckouts(checkoutResults);
  const klaviyoLookup = buildKlaviyoLookup(klaviyoProfiles);

  const assignments = readAssignments();
  const allLeads = checkoutResults
    .flatMap((result) => result.records.map((record) => ({ record, market: result.market })))
    .filter(Boolean)
    .map(({ record, market }) => normalizeCheckout(record, market, productLookup, klaviyoLookup))
    .filter((lead) => markets.includes(lead.market))
    .map((lead) => applyAssignment(lead, assignments))
    .sort(sortByGradeThenDate);

  const withFunnel = applyFunnelStatus(allLeads)
    .map((lead) => ({ ...lead, assignmentSource: lead.assignedSales ? "Manual" : "" }))
    .sort(sortByGradeThenDate);
  const summary = buildSummary(withFunnel);

  return sendJson(res, 200, {
    fetchedAt: startedAt.toISOString(),
    count: withFunnel.length,
    markets,
    source: useEnriched ? "enriched" : "raw",
    klaviyoStatus: includeKlaviyo ? "loaded" : "skipped",
    salesUsers: SALES_USERS,
    summary,
    leads: withFunnel,
  });
}

async function proxyDataHub(res, endpoint) {
  if (!DATA_HUB_BASE_URL || !DATA_HUB_API_KEY) {
    return sendJson(res, 400, { error: "Data Hub environment variables are missing." });
  }

  const response = await fetch(`${DATA_HUB_BASE_URL}${endpoint}`, {
    headers: { "x-api-key": DATA_HUB_API_KEY },
  });
  const text = await response.text();
  res.writeHead(response.status, {
    "Content-Type": response.headers.get("content-type") || "application/json; charset=utf-8",
  });
  res.end(text);
}

async function fetchDataHubRecords(table, country, limit) {
  const params = new URLSearchParams({ table, limit: String(limit) });
  if (country) params.set("country", country);

  const response = await fetch(`${DATA_HUB_BASE_URL}/api/data-hub/records?${params}`, {
    headers: { "x-api-key": DATA_HUB_API_KEY },
  });

  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch (error) {
    throw new Error(`Data Hub returned invalid JSON for ${table}/${country}.`);
  }

  if (!response.ok) {
    throw new Error(payload.error || `Data Hub returned ${response.status} for ${table}/${country}.`);
  }

  return payload;
}

async function fetchAbandonedCartLeads(country, limit, source = "enriched") {
  const pageSize = Math.min(Math.max(Number(limit || 5000), 1), 5000);
  const rows = [];
  let offset = 0;
  let hasMore = true;

  while (hasMore) {
    const params = new URLSearchParams({
      country,
      limit: String(pageSize),
      offset: String(offset),
    });
    const report = source === "raw" ? "abandoned-cart-leads" : "abandoned-cart-leads-enriched";
    const response = await fetch(`${DATA_HUB_BASE_URL}/api/data-hub/reports/${report}?${params}`, {
      headers: { "x-api-key": DATA_HUB_API_KEY },
    });
    const text = await response.text();
    let payload = {};
    try {
      payload = text ? JSON.parse(text) : {};
    } catch (error) {
      throw new Error(`Data Hub returned invalid JSON for ${report}/${country}.`);
    }
    if (!response.ok) {
      throw new Error(payload.error || `Data Hub returned ${response.status} for ${report}/${country}.`);
    }

    const pageRows = extractRecords(payload);
    rows.push(...pageRows);
    offset += pageRows.length;
    hasMore = Boolean(payload.hasMore || payload.has_more) && pageRows.length > 0;
  }

  return rows;
}

async function fetchKlaviyoProfiles(markets) {
  const rows = [];
  for (const market of markets) {
    const payload = await fetchDataHubRecords("klaviyo_profiles_raw", market, 5000);
    rows.push(...extractRecords(payload));
  }
  return dedupeBy(rows, (row) => row.profile_id || row.raw?.id || `${row.email || ""}:${row.phone_number || ""}`);
}

async function buildKlaviyoProfilesFromCheckouts(checkoutResults) {
  const rows = [];
  for (const result of checkoutResults) {
    const market = text(result.market).toUpperCase();
    const emails = collectCheckoutEmails(result.records);
    if (!emails.length) continue;
    const records = await fetchKlaviyoProfileLookup(market, emails);
    rows.push(...records);
  }
  return dedupeBy(rows, (row) => row.profile_id || `${row.country_normalized || ""}:${row.matched_email || row.email || ""}`);
}

function collectCheckoutEmails(records) {
  const emails = new Set();
  for (const record of records) {
    const raw = record.raw || record.payload || record.data || record.checkout || record;
    const customer = raw.customer || {};
    const email = normalizeEmail(raw.email || customer.email || record.email || record.customer_email);
    if (email) emails.add(email);
  }
  return [...emails];
}

async function fetchKlaviyoProfileLookup(country, emails) {
  const rows = [];
  const chunkSize = 25;
  for (let index = 0; index < emails.length; index += chunkSize) {
    const contacts = emails.slice(index, index + chunkSize).map((email) => ({ email }));
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    let response;
    try {
      response = await fetch(`${DATA_HUB_BASE_URL}/api/data-hub/reports/klaviyo-profile-lookup`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": DATA_HUB_API_KEY,
        },
        body: JSON.stringify({ country, contacts }),
        signal: controller.signal,
      });
    } catch (error) {
      console.warn(`Skipped slow Klaviyo lookup batch for ${country}: ${error.message}`);
      clearTimeout(timeout);
      continue;
    } finally {
      clearTimeout(timeout);
    }

    const text = await response.text();
    let payload = {};
    try {
      payload = text ? JSON.parse(text) : {};
    } catch (error) {
      console.warn(`Skipped invalid Klaviyo lookup batch for ${country}.`);
      continue;
    }

    if (!response.ok) {
      console.warn(payload.error || `Skipped Klaviyo lookup batch for ${country}: ${response.status}.`);
      continue;
    }

    rows.push(...extractRecords(payload));
  }
  return rows;
}

async function buildProductLookupFromCheckouts(checkoutResults) {
  const lookup = {};
  for (const result of checkoutResults) {
    const market = text(result.market).toUpperCase();
    const skus = collectCheckoutSkus(result.records);
    const records = skus.length ? await fetchProductLookup(market, skus) : [];
    lookup[market] = buildProductLookupFromProductLookupRecords(records, market);
  }
  return lookup;
}

function collectCheckoutSkus(records) {
  const skus = new Set();
  for (const record of records) {
    const raw = record.raw || record.payload || record.data || record.checkout || record;
    for (const item of getLineItems(raw)) {
      if (isPpProduct(item)) continue;
      const sku = normalizeSku(item.sku);
      if (sku) skus.add(sku);
    }
  }
  return [...skus];
}

async function fetchProductLookup(country, skus) {
  const response = await fetch(`${DATA_HUB_BASE_URL}/api/data-hub/reports/product-lookup`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": DATA_HUB_API_KEY,
    },
    body: JSON.stringify({ country, skus }),
  });

  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch (error) {
    throw new Error(`Data Hub returned invalid JSON for product-lookup/${country}.`);
  }

  if (!response.ok) {
    throw new Error(payload.error || `Data Hub returned ${response.status} for product-lookup/${country}.`);
  }

  return extractRecords(payload);
}

function extractRecords(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload.records)) return payload.records;
  if (Array.isArray(payload.rows)) return payload.rows;
  if (Array.isArray(payload.data)) return payload.data;
  return [];
}

function dedupeBy(rows, getKey) {
  const seen = new Set();
  const deduped = [];
  for (const row of rows) {
    const key = text(getKey(row));
    if (!key || seen.has(key)) continue;
    seen.add(key);
    deduped.push(row);
  }
  return deduped;
}

function normalizeCheckout(record, market, productLookup, klaviyoLookup) {
  market = text(market || record.country).toUpperCase();
  const raw = record.raw || record.payload || record.data || record.checkout || record;
  const checkoutId = text(raw.id || raw.checkout_gid || raw.checkout_id || raw.checkoutId || raw.token || record.id);
  const checkoutName = text(raw.name || raw.checkout_name || raw.checkoutName || record.name || (checkoutId ? `#${checkoutId}` : ""));
  const enrichedProductLookup = buildProductLookupFromEnriched(raw.product_lookup_json, market);
  const lineItems = getLineItems(raw)
    .filter((item) => !isPpProduct(item))
    .map((item) => enrichLineItemFromProducts(item, enrichedProductLookup || productLookup?.[market]));
  const shipping = raw.shipping_address || raw.shippingAddress || {};
  const billing = raw.billing_address || raw.billingAddress || {};
  const customer = raw.customer || {};
  const subtotal = number(raw.subtotal || raw.subtotal_price || raw.subtotalPrice || raw.total_price || raw.totalPrice || record.subtotal || record.total_price);
  const createdAt = text(raw.created_at || raw.createdAt || record.created_at || record.createdAt);
  const email = text(raw.email || customer.email || record.email || record.customer_email);
  const phone = text(
    raw.phone ||
      raw.sms_marketing_phone ||
      shipping.phone ||
      billing.phone ||
      customer.phone ||
      customer.default_address?.phone ||
      record.phone ||
      record.shipping_phone,
  );
  const klaviyoProfile = findKlaviyoProfile(market, email, klaviyoLookup);
  const klaviyoEmailSubscribed = getLookupMarketingState(raw.klaviyo_email_subscribed) || getKlaviyoMarketingState(klaviyoProfile, "email");
  const klaviyoTextSubscribed = getLookupMarketingState(raw.klaviyo_sms_subscribed) || getKlaviyoMarketingState(klaviyoProfile, "sms");
  const shippingName = text(raw.shipping_name || shipping.name || [shipping.first_name, shipping.last_name].filter(Boolean).join(" "));
  const billingName = text(billing.name || [billing.first_name, billing.last_name].filter(Boolean).join(" "));
  const customerName = text(
    raw.customer_name ||
      raw.customerName ||
      shippingName ||
      billingName ||
      [customer.first_name, customer.last_name].filter(Boolean).join(" "),
  );
  const state = normalizeState(raw.shipping_state || shipping.province_code || shipping.province || shipping.state || billing.province_code || billing.province || "");
  const currency = text(raw.currency || raw.presentment_currency || record.currency || COUNTRY_META[market]?.currency || "USD");
  const ageHours = createdAt ? Math.max(0, (Date.now() - new Date(createdAt).getTime()) / 36e5) : null;
  const productKey = lineItems.map((item) => normalizeComparable(item.sku || item.title)).sort().join("|");
  const enrichedGrade = text(raw.grade);
  const grade = enrichedGrade && enrichedGrade !== "!" ? enrichedGrade : buildGrade(subtotal, ageHours, klaviyoEmailSubscribed, klaviyoTextSubscribed);
  const recoveredOrderTags = getRecoveredOrderTags(raw);
  const recoveredBySalesName = getRecoveredBySalesName(raw, recoveredOrderTags);
  const recoveredBySales = booleanValue(raw.recovered_by_sales || raw.recoveredBySales) || Boolean(recoveredBySalesName);
  const recovered = Boolean(
    raw.completed_at ||
      raw.completedAt ||
      raw.order_id ||
      raw.orderId ||
      booleanValue(raw.is_recovered || raw.isRecovered),
  );

  return {
    id: checkoutId || checkoutName,
    market,
    checkout: checkoutName,
    grade,
    name: customerName || shippingName || billingName || "No name",
    shippingName,
    billingName,
    subtotal,
    currency,
    checkoutPhone: phone,
    checkoutEmail: email,
    createdAt,
    createdAtVancouver: formatVancouverDateTime(createdAt),
    shippingState: state,
    timeZone: normalizeTimeZone(raw.time_zone) || getTimeZoneForState(state, market),
    checkoutDiscountCode: getDiscountCode(raw),
    checkoutDiscountAmount: number(raw.discount_amount || raw.total_discounts || raw.totalDiscounts || record.discount_amount),
    klaviyoEmailSubscribed,
    klaviyoTextSubscribed,
    klaviyoMaximumDiscount: calculateKlaviyoMaxDiscount(subtotal),
    address: formatAddress(shipping || billing),
    lineItems,
    productKey,
    ageHours,
    source: text(raw.source_name || raw.sourceName || raw.source || ""),
    recovered,
    recoveredOrderNumber: text(raw.recovered_order_name || raw.order?.name || raw.order_name || raw.orderName || raw.order_id || raw.orderId),
    recoveredBySales,
    recoveredBySalesName,
    recoveredOrderTags,
    rawUpdatedAt: text(raw.updated_at || raw.updatedAt || record.updated_at || record.updatedAt),
    leadStatus: normalizeLeadStatus(raw.lead_status || ""),
    salesStatus: normalizeLeadStatus(raw.lead_status || ""),
    funnelStatus: normalizeFunnelStatus(raw.funnel_status || ""),
    funnelReason: text(raw.funnel_reason || ""),
  };
}

function getLineItems(raw) {
  const direct = raw.line_items_json || raw.line_items || raw.lineItems;
  if (Array.isArray(direct)) return direct.map(normalizeLineItem);
  if (Array.isArray(direct?.edges)) return direct.edges.map((edge) => normalizeLineItem(edge.node || edge));
  return [];
}

function normalizeLineItem(item) {
  const sku = text(item.sku || item.variant_sku || item.variantSku);
  const title = text(item.title || item.name || item.product_title || item.productTitle || item.presentment_title);
  const quantity = number(item.quantity || 1);
  const checkoutPrice = number(
    item.price ||
      item.line_price ||
      item.linePrice ||
      item.original_line_price ||
      item.originalUnitPriceSet?.shopMoney?.amount ||
      item.discountedUnitPriceSet?.shopMoney?.amount,
  );
  const currentPrice = number(item.current_price || item.currentPrice || item.variant?.price || item.product?.price);
  const inventory = number(item.inventory_quantity || item.inventoryQuantity || item.variant?.inventory_quantity || item.available);
  const productUrl = text(item.product_url || item.productUrl || item.url || "");
  return { title, sku, quantity, checkoutPrice, currentPrice, inventory, productUrl };
}

function buildProductLookupByMarket(results) {
  const lookup = {};
  for (const result of results) {
    const market = text(result.market).toUpperCase();
    lookup[market] = buildProductLookup(result.records, market);
  }
  return lookup;
}

function buildProductLookupFromProductLookupRecords(records, market) {
  const lookup = new Map();
  for (const record of records) {
    const sku = normalizeSku(record.sku || record.requested_sku);
    if (!sku) continue;
    lookup.set(sku, {
      title: text(record.product_title || record.title),
      currentPrice: number(record.current_price || record.price),
      inventory: getLookupInventory(record),
      productUrl: text(record.product_url) || getProductUrlFromHandle(record.handle, market),
    });
  }
  return lookup;
}

function buildProductLookupFromEnriched(records, market) {
  const direct = normalizeJsonArray(records);
  if (!direct.length) return null;
  return buildProductLookupFromProductLookupRecords(direct, market);
}

function normalizeJsonArray(value) {
  if (Array.isArray(value)) return value;
  if (typeof value === "string" && value.trim()) {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      return [];
    }
  }
  return [];
}

function buildProductLookup(records, market) {
  const lookup = new Map();
  for (const record of records) {
    const raw = record.raw || {};
    const title = text(record.title || raw.title);
    const handle = text(record.handle || raw.handle);
    const productUrl = getProductUrl(record, raw, market);
    for (const variant of getProductVariants(raw)) {
      const sku = normalizeSku(variant.sku);
      if (!sku) continue;
      lookup.set(sku, {
        title,
        currentPrice: number(variant.price || variant.compareAtPrice || variant.compare_at_price),
        inventory: getVariantInventory(variant),
        productUrl,
      });
    }
  }
  return lookup;
}

function getLookupInventory(record) {
  const quantity = record.inventory_quantity ?? record.inventoryQuantity;
  if (quantity !== undefined && quantity !== null && quantity !== "") return number(quantity);
  const available = record.available_for_sale ?? record.availableForSale;
  if (available === true) return "Available";
  if (available === false) return "Not available";
  return "";
}

function getProductVariants(raw) {
  const variants = raw.variants;
  if (Array.isArray(variants?.edges)) return variants.edges.map((edge) => edge.node || edge).filter(Boolean);
  if (Array.isArray(variants)) return variants;
  return [];
}

function enrichLineItemFromProducts(item, productLookup) {
  const product = productLookup?.get(normalizeSku(item.sku));
  if (!product) return item;
  return {
    ...item,
    title: item.title || product.title,
    currentPrice: product.currentPrice || item.currentPrice,
    inventory: product.inventory || item.inventory,
    productUrl: product.productUrl || item.productUrl,
  };
}

function getVariantInventory(variant) {
  const quantity = variant.inventoryQuantity ?? variant.inventory_quantity ?? variant.inventory_quantity_adjustment;
  if (quantity !== undefined && quantity !== null && quantity !== "") return number(quantity);
  const available = variant.availableForSale ?? variant.available_for_sale ?? variant.available;
  if (available === true) return "Available";
  if (available === false) return "Not available";
  return "";
}

function getProductUrl(record, raw, market) {
  const directUrl = text(raw.onlineStoreUrl || raw.online_store_url || record.product_url || raw.product_url);
  if (directUrl) return directUrl;
  const handle = text(record.handle || raw.handle);
  return getProductUrlFromHandle(handle, market);
}

function getProductUrlFromHandle(handle, market) {
  const baseUrl = COUNTRY_META[market]?.siteBaseUrl;
  return handle && baseUrl ? `${baseUrl}/products/${handle}` : "";
}

function normalizeSku(value) {
  return text(value).toUpperCase();
}

function isPpProduct(item) {
  const sku = text(item.sku).toUpperCase();
  const title = text(item.title).toUpperCase();
  return sku.includes("PP") || sku.includes("PSP") || title.includes("SURCHARGE");
}

function applyAssignment(lead, assignments) {
  const saved = assignments[assignmentKey(lead)] || {};
  const savedLeadStatus = saved.leadStatus || saved.salesStatus || "";
  return {
    ...lead,
    assignedSales: saved.sales || "",
    leadStatus: savedLeadStatus,
    salesStatus: savedLeadStatus,
    salesNotes: saved.notes || "",
    funnelStatus: normalizeFunnelStatus(saved.funnelStatus || lead.funnelStatus || ""),
    manualStatus: normalizeFunnelStatus(saved.manualStatus || ""),
    manualNotes: saved.manualStatus === "No Contact" && !saved.manualNotes ? "No checkout phone" : saved.manualNotes || "",
    assignedAt: saved.assignedAt || "",
    lastWorklogAt: saved.updatedAt || "",
  };
}

function applyFunnelStatus(leads) {
  const latestByNameProducts = new Map();
  for (const lead of leads) {
    const key = `${normalizeComparable(lead.name)}|${lead.productKey}`;
    const previous = latestByNameProducts.get(key);
    if (!previous || new Date(lead.createdAt).getTime() > new Date(previous.createdAt).getTime()) {
      latestByNameProducts.set(key, lead);
    }
  }

  return leads.map((lead) => {
    let status = lead.funnelStatus || "Ready";
    let reason = lead.funnelReason || status;
    const savedLeadStatus = normalizeLeadStatus(lead.leadStatus || lead.salesStatus);
    const recoveredFromData = lead.recovered || status === "Recovered";

    if (recoveredFromData) {
      status = "Recovered";
      reason = buildRecoveredReason(lead);
    } else if (lead.manualStatus && !(lead.manualStatus === "No Phone" && lead.checkoutPhone)) {
      status = lead.manualStatus;
      reason = lead.manualNotes || "Manually updated";
    } else if (!lead.funnelStatus && lead.ageHours !== null && lead.ageHours < 72) {
      status = "Too New";
      reason = "Less than 72 hours old";
    } else if (!lead.funnelStatus && !lead.checkoutPhone) {
      status = "No Phone";
      reason = "No checkout phone";
    } else if (!lead.funnelStatus && latestByNameProducts.get(`${normalizeComparable(lead.name)}|${lead.productKey}`)?.id !== lead.id) {
      status = "Duplicate";
      reason = "Older checkout with same name and products";
    }
    const validFunnelStatus = status === "Ready" || status === "Older Than 30 Days";
    const leadStatus =
      recoveredFromData
        ? lead.recoveredBySales
          ? "Recovered by Sales"
          : "Recovered Auto"
        : savedLeadStatus === "Recovered Auto" || savedLeadStatus === "Recovered by Sales"
          ? savedLeadStatus
          : validFunnelStatus
            ? savedLeadStatus || "Valid"
            : "Invalid";
    return {
      ...lead,
      assignedSales: recoveredFromData ? "" : lead.assignedSales,
      assignedAt: recoveredFromData ? "" : lead.assignedAt,
      funnelStatus: status,
      funnelReason: reason,
      leadStatus,
      salesStatus: leadStatus,
    };
  });
}

function buildRecoveredReason(lead) {
  const order = lead.recoveredOrderNumber ? `Recovered order ${lead.recoveredOrderNumber}` : "Checkout already recovered";
  if (lead.recoveredBySalesName) return `${order}; sales tag: ${lead.recoveredBySalesName}`;
  if (lead.recoveredBySales) return `${order}; sales tag found`;
  return `${order}; no sales tag`;
}

function getRecoveredOrderTags(raw) {
  return normalizeTags(
    raw.recovered_order_tags ||
      raw.recoveredOrderTags ||
      raw.recovered_order?.tags ||
      raw.recoveredOrder?.tags ||
      raw.order_tags ||
      raw.orderTags ||
      raw.order?.tags,
  );
}

function getRecoveredBySalesName(raw, recoveredOrderTags) {
  const direct = text(
    raw.recovered_by_sales_name ||
      raw.recoveredBySalesName ||
      raw.recovered_sales_name ||
      raw.recoveredSalesName ||
      raw.sales_name ||
      raw.salesName ||
      raw.order?.sales_name ||
      raw.order?.salesName,
  );
  return matchSalesName(direct) || matchSalesName(recoveredOrderTags.join(" "));
}

function normalizeTags(value) {
  if (Array.isArray(value)) return value.map(text).filter(Boolean);
  if (typeof value === "string" && value.trim()) {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map(text).filter(Boolean);
    } catch (error) {
      // Fall back to comma splitting below.
    }
    return value.split(",").map(text).filter(Boolean);
  }
  return [];
}

function matchSalesName(value) {
  const haystack = normalizeComparable(value);
  if (!haystack) return "";
  return SALES_USERS.find((name) => name !== "Non-sales" && haystack.includes(normalizeComparable(name))) || "";
}

function booleanValue(value) {
  if (value === true) return true;
  if (value === false || value === null || value === undefined || value === "") return false;
  return ["true", "1", "yes", "y"].includes(text(value).toLowerCase());
}

function buildSummary(leads) {
  const byMarket = {};
  const bySales = {};
  const latestCreatedAt = {};
  for (const lead of leads) {
    byMarket[lead.market] ||= {
      total: 0,
      valid: 0,
      validAvailable: 0,
      assigned: 0,
      amount: 0,
      validAmount: 0,
      validAssignedAmount: 0,
      ageBuckets: { under72h: 0, h72To1w: 0, w1To1m: 0, over1m: 0 },
    };
    byMarket[lead.market].total += 1;
    byMarket[lead.market].amount += lead.subtotal;
    incrementAgeBucket(byMarket[lead.market].ageBuckets, lead.ageHours);
    if (lead.leadStatus === "Valid") {
      byMarket[lead.market].valid += 1;
      byMarket[lead.market].validAmount += lead.subtotal;
    }
    if (lead.leadStatus === "Valid" && !lead.assignedSales) byMarket[lead.market].validAvailable += 1;
    if (lead.assignedSales && lead.leadStatus === "Valid") {
      byMarket[lead.market].assigned += 1;
      byMarket[lead.market].validAssignedAmount += lead.subtotal;
    }
    if (!latestCreatedAt[lead.market] || new Date(lead.createdAt) > new Date(latestCreatedAt[lead.market])) {
      latestCreatedAt[lead.market] = lead.createdAt;
    }
    if (lead.assignedSales && lead.leadStatus === "Valid") {
      bySales[lead.assignedSales] ||= { US: 0, CA: 0, AU: 0, total: 0, lastAssignedAt: "" };
      bySales[lead.assignedSales][lead.market] += 1;
      bySales[lead.assignedSales].total += 1;
      if (!bySales[lead.assignedSales].lastAssignedAt || new Date(lead.assignedAt) > new Date(bySales[lead.assignedSales].lastAssignedAt)) {
        bySales[lead.assignedSales].lastAssignedAt = lead.assignedAt;
      }
    }
  }
  return { byMarket, bySales, latestCreatedAt };
}

function incrementAgeBucket(buckets, ageHours) {
  if (ageHours === null || ageHours === undefined || !Number.isFinite(Number(ageHours))) return;
  if (ageHours < 72) buckets.under72h += 1;
  else if (ageHours < 24 * 7) buckets.h72To1w += 1;
  else if (ageHours <= 24 * 30) buckets.w1To1m += 1;
  else buckets.over1m += 1;
}

async function handleSaveAssignment(req, res) {
  const body = await readJsonBody(req);
  const id = text(body.id);
  const market = text(body.market).toUpperCase();
  if (!id || !COUNTRY_META[market]) {
    return sendJson(res, 400, { error: "Lead id and market are required." });
  }

  const assignments = readAssignments();
  const key = `${market}:${id}`;
  const previous = assignments[key] || {};
  const now = new Date().toISOString();
  const leadStatus = normalizeLeadStatus(body.leadStatus || body.salesStatus || previous.leadStatus || previous.salesStatus || "Valid");
  assignments[key] = {
    ...previous,
    id,
    market,
    checkoutName: text(body.checkoutName || body.checkout || previous.checkoutName || ""),
    sales: text(body.sales),
    leadStatus,
    salesStatus: leadStatus,
    notes: text(body.notes),
    funnelStatus: text(body.funnelStatus || previous.funnelStatus || ""),
    manualStatus: text(body.manualStatus || previous.manualStatus || ""),
    manualNotes: text(body.manualNotes || previous.manualNotes || ""),
    assignedAt: body.sales && body.sales !== previous.sales ? now : previous.assignedAt || "",
    updatedAt: now,
    dataHubSyncedAt: previous.dataHubSyncedAt || "",
    dataHubSyncError: "",
  };

  const syncResult = await syncAssignmentToDataHub(assignments[key], body);
  assignments[key].dataHubSyncedAt = syncResult.syncedAt || assignments[key].dataHubSyncedAt || "";
  assignments[key].dataHubSyncError = syncResult.error || "";
  writeAssignments(assignments);
  return sendJson(res, 200, {
    ok: true,
    assignment: assignments[key],
    dataHubSynced: Boolean(syncResult.syncedAt),
    dataHubSyncError: syncResult.error || "",
  });
}

async function syncAssignmentToDataHub(assignment, requestBody) {
  if (!DATA_HUB_ASSIGNMENTS_WRITE_PATH) {
    return { skipped: true };
  }
  if (!DATA_HUB_BASE_URL || !DATA_HUB_API_KEY) {
    return { error: "Data Hub environment variables are missing." };
  }

  const endpoint = DATA_HUB_ASSIGNMENTS_WRITE_PATH.startsWith("/")
    ? DATA_HUB_ASSIGNMENTS_WRITE_PATH
    : `/${DATA_HUB_ASSIGNMENTS_WRITE_PATH}`;
  const payload = {
    country: assignment.market,
    checkout_gid: assignment.id,
    checkout_name: text(requestBody.checkoutName || requestBody.checkout || assignment.checkoutName || ""),
    assigned_sales: assignment.sales,
    lead_status: assignment.leadStatus,
    sales_notes: assignment.notes,
    assigned_at: assignment.assignedAt || null,
    updated_at: assignment.updatedAt,
    updated_by: text(requestBody.updatedBy || requestBody.updated_by || requestBody.userEmail || ""),
  };

  try {
    const response = await fetch(`${DATA_HUB_BASE_URL}${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": DATA_HUB_API_KEY,
      },
      body: JSON.stringify(payload),
    });
    const responseText = await response.text();
    if (!response.ok) {
      return { error: getDataHubErrorMessage(response.status, responseText) };
    }
    return { syncedAt: new Date().toISOString() };
  } catch (error) {
    return { error: error.message };
  }
}

function getDataHubErrorMessage(status, responseText) {
  try {
    const parsed = JSON.parse(responseText || "{}");
    return parsed.error ? `Data Hub ${status}: ${parsed.error}` : `Data Hub ${status}: ${responseText.slice(0, 180)}`;
  } catch (error) {
    return `Data Hub ${status}: ${responseText.slice(0, 180)}`;
  }
}

function readAssignments() {
  if (!fs.existsSync(ASSIGNMENTS_FILE)) return {};
  try {
    const parsed = JSON.parse(fs.readFileSync(ASSIGNMENTS_FILE, "utf8"));
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch (error) {
    return {};
  }
}

function writeAssignments(assignments) {
  fs.writeFileSync(ASSIGNMENTS_FILE, JSON.stringify(assignments, null, 2), "utf8");
}

function assignmentKey(lead) {
  return `${lead.market}:${lead.id}`;
}

function normalizeFunnelStatus(value) {
  const status = text(value);
  return status === "No Contact" ? "No Phone" : status;
}

function sortByGradeThenDate(a, b) {
  return gradeRank(a.grade) - gradeRank(b.grade) || new Date(b.createdAt) - new Date(a.createdAt);
}

function gradeRank(grade) {
  const gradeOrder = { "A+": 0, A: 2, "A-": 4, "B+": 6, B: 8, "B-": 10 };
  const value = text(grade);
  const normalized = value.replace("!", "");
  const bangPriority = value.includes("!") ? -1 : 0;
  return (gradeOrder[normalized] ?? 99) + bangPriority;
}

function buildKlaviyoLookup(records) {
  const lookup = { byMarketEmail: new Map() };
  for (const record of records) {
    const profile = normalizeKlaviyoProfile(record);
    if (!profile) continue;
    for (const email of profile.emails) lookup.byMarketEmail.set(`${profile.market}:${email}`, profile);
  }
  return lookup;
}

function normalizeKlaviyoProfile(record) {
  const raw = record.raw || record.profile || record.data || {};
  const attributes = raw.attributes || raw;
  const email = normalizeEmail(record.matched_email || record.email || attributes.email);
  const market = text(record.country_normalized || record.country || attributes.country).toUpperCase();
  const subscriptions = normalizeSubscriptions(record.subscriptions || attributes.subscriptions || raw.subscriptions);
  const profile = {
    id: text(record.profile_id || raw.id || record.id),
    market,
    emails: email ? [email] : [],
    emailState: marketingStateFromLookup(record.klaviyo_email_subscribed) || marketingStateFromSubscription(subscriptions?.email?.marketing),
    smsState: marketingStateFromLookup(record.klaviyo_sms_subscribed) || marketingStateFromSubscription(subscriptions?.sms?.marketing),
  };
  if (!profile.market || !profile.emails.length) return null;
  return profile;
}

function normalizeSubscriptions(value) {
  if (!value) return {};
  if (typeof value === "string") {
    try {
      return JSON.parse(value);
    } catch (error) {
      return {};
    }
  }
  return value;
}

function marketingStateFromSubscription(marketing) {
  if (!marketing) return "Unknown";
  if (marketing.can_receive_email_marketing === true || marketing.can_receive_sms_marketing === true) return "Subscribed";
  const consent = text(marketing.consent || marketing.status || marketing.state).toLowerCase();
  if (["subscribed", "opted_in", "confirmed", "true"].includes(consent)) return "Subscribed";
  if (!consent) return "Unknown";
  return "Not subscribed";
}

function marketingStateFromLookup(value) {
  const state = text(value).toLowerCase();
  if (!state) return "";
  if (state === "subscribed") return "Subscribed";
  if (state.includes("not subscribed") || state.includes("never_subscribed") || state.includes("unsubscribed")) {
    return "Not subscribed";
  }
  return "";
}

function getLookupMarketingState(value) {
  return marketingStateFromLookup(value);
}

function findKlaviyoProfile(market, email, lookup) {
  if (!lookup) return null;
  const emailKey = normalizeEmail(email);
  const marketKey = text(market).toUpperCase();
  return emailKey && marketKey ? lookup.byMarketEmail.get(`${marketKey}:${emailKey}`) || null : null;
}

function getKlaviyoMarketingState(profile, type) {
  if (!profile) return "Unknown";
  return type === "email" ? profile.emailState || "Unknown" : profile.smsState || "Unknown";
}

function normalizeEmail(value) {
  return text(value).toLowerCase();
}

function buildGrade(subtotal, ageHours, klaviyoEmailSubscribed, klaviyoTextSubscribed) {
  const base = subtotal > 5000 ? "A" : "B";
  let suffix = "";
  if (ageHours !== null && ageHours >= 72 && ageHours < 24 * 7) suffix = "+";
  if (ageHours !== null && ageHours >= 24 * 7 && ageHours <= 24 * 30) suffix = "";
  if (ageHours !== null && ageHours > 24 * 30) suffix = "-";
  const unsubscribed = klaviyoEmailSubscribed !== "Subscribed" && klaviyoTextSubscribed !== "Subscribed";
  return `${base}${suffix}${unsubscribed ? "!" : ""}`;
}

function calculateKlaviyoMaxDiscount(subtotal) {
  if (subtotal <= 2000) return 25;
  if (subtotal <= 5000) return 100;
  return 200;
}

function normalizeLeadStatus(value) {
  const status = text(value);
  if (status === "Recovered") return "Recovered by Sales";
  return ["Valid", "Invalid", "Recovered Auto", "Recovered by Sales"].includes(status) ? status : "Valid";
}

function getDiscountCode(raw) {
  const discounts = raw.discount_codes || raw.discountCodes || raw.applied_discounts || raw.appliedDiscounts || [];
  if (Array.isArray(discounts) && discounts.length) {
    return discounts.map((discount) => discount.code || discount.title || discount).filter(Boolean).join("; ");
  }
  return text(raw.discount_code || raw.discountCode);
}

function getMarketingState(raw, type) {
  const consent =
    type === "email"
      ? raw.email_marketing_consent || raw.emailMarketingConsent || raw.customer?.email_marketing_consent
      : raw.sms_marketing_consent || raw.smsMarketingConsent || raw.customer?.sms_marketing_consent;
  const direct =
    type === "email"
      ? raw.buyer_accepts_marketing || raw.email_subscribed || raw.klaviyo_email_subscribed
      : raw.buyer_accepts_sms_marketing || raw.sms_subscribed || raw.klaviyo_sms_subscribed;
  if (direct === true) return "Subscribed";
  const state = text(consent?.state || consent?.marketingState || consent?.status || direct).toLowerCase();
  if (["subscribed", "opted_in", "confirmed", "true"].includes(state)) return "Subscribed";
  if (!state) return "Unknown";
  return "Not subscribed";
}

function formatAddress(address) {
  if (typeof address === "string") return address;
  if (!address) return "";
  return [
    address.address1,
    address.address2,
    [address.city, address.province_code || address.province, address.zip].filter(Boolean).join(", "),
    address.country || address.country_code,
    address.phone,
  ]
    .filter(Boolean)
    .map(text)
    .join("\n");
}

function formatVancouverDateTime(value) {
  if (!value) return "";
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Vancouver",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZoneName: "short",
  }).format(new Date(value));
}

function normalizeState(value) {
  const state = text(value).trim().toUpperCase();
  const names = {
    ALABAMA: "AL",
    ALASKA: "AK",
    ARIZONA: "AZ",
    ARKANSAS: "AR",
    CALIFORNIA: "CA",
    COLORADO: "CO",
    CONNECTICUT: "CT",
    DELAWARE: "DE",
    FLORIDA: "FL",
    GEORGIA: "GA",
    HAWAII: "HI",
    IDAHO: "ID",
    ILLINOIS: "IL",
    INDIANA: "IN",
    IOWA: "IA",
    KANSAS: "KS",
    KENTUCKY: "KY",
    LOUISIANA: "LA",
    MAINE: "ME",
    MARYLAND: "MD",
    MASSACHUSETTS: "MA",
    MICHIGAN: "MI",
    MINNESOTA: "MN",
    MISSISSIPPI: "MS",
    MISSOURI: "MO",
    MONTANA: "MT",
    NEBRASKA: "NE",
    NEVADA: "NV",
    "NEW HAMPSHIRE": "NH",
    "NEW JERSEY": "NJ",
    "NEW MEXICO": "NM",
    "NEW YORK": "NY",
    "NORTH CAROLINA": "NC",
    "NORTH DAKOTA": "ND",
    OHIO: "OH",
    OKLAHOMA: "OK",
    OREGON: "OR",
    PENNSYLVANIA: "PA",
    "RHODE ISLAND": "RI",
    "SOUTH CAROLINA": "SC",
    "SOUTH DAKOTA": "SD",
    TENNESSEE: "TN",
    TEXAS: "TX",
    UTAH: "UT",
    VERMONT: "VT",
    VIRGINIA: "VA",
    WASHINGTON: "WA",
    "WEST VIRGINIA": "WV",
    WISCONSIN: "WI",
    WYOMING: "WY",
  };
  return names[state] || state;
}

function getTimeZoneForState(state, market) {
  if (!state) return "";
  if (market === "AU") return getAuTimeZoneForState(state);
  if (market === "CA") {
    if (["BC", "YT"].includes(state)) return "PT";
    if (["AB", "NT"].includes(state)) return "MT";
    if (["SK", "MB"].includes(state)) return "CT";
    if (["ON", "QC", "NU"].includes(state)) return "ET";
    if (["NB", "NS", "PE"].includes(state)) return "AT";
    if (state === "NL") return "NT";
    return "";
  }
  const pacific = new Set(["CA", "NV", "OR", "WA"]);
  const mountain = new Set(["AZ", "CO", "ID", "MT", "NM", "UT", "WY"]);
  const central = new Set(["AL", "AR", "IA", "IL", "KS", "LA", "MN", "MO", "MS", "ND", "NE", "OK", "SD", "TX", "WI"]);
  const eastern = new Set(["CT", "DC", "DE", "FL", "GA", "IN", "KY", "MA", "MD", "ME", "MI", "NC", "NH", "NJ", "NY", "OH", "PA", "RI", "SC", "TN", "VA", "VT", "WV"]);
  if (pacific.has(state)) return "PT";
  if (mountain.has(state)) return "MT";
  if (central.has(state)) return "CT";
  if (eastern.has(state)) return "ET";
  if (state === "AK") return "AKT";
  if (state === "HI") return "HT";
  return "";
}

function normalizeTimeZone(value) {
  const zone = text(value);
  if (!zone) return "";
  const ianaMap = {
    "America/Los_Angeles": "PT",
    "America/Denver": "MT",
    "America/Chicago": "CT",
    "America/New_York": "ET",
    "America/Vancouver": "PT",
    "America/Edmonton": "MT",
    "America/Winnipeg": "CT",
    "America/Toronto": "ET",
    "America/Halifax": "AT",
    "America/St_Johns": "NT",
    "Australia/Perth": "AWST",
    "Australia/Adelaide": "ACST",
    "Australia/Darwin": "ACST",
    "Australia/Brisbane": "AEST",
    "Australia/Sydney": "AEST",
    "Australia/Melbourne": "AEST",
  };
  return ianaMap[zone] || zone;
}

function getAuTimeZoneForState(state) {
  if (["WA"].includes(state)) return "AWT";
  if (["NT", "SA"].includes(state)) return "ACT";
  if (["ACT", "NSW", "QLD", "TAS", "VIC"].includes(state)) return "AET";
  return "";
}

function normalizeComparable(value) {
  return text(value).toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function normalizeAuthMode(value) {
  const mode = text(value).toLowerCase().replace(/[-\s]+/g, "_");
  return mode === "cloudflare_access" || mode === "cloudflare" ? "cloudflare_access" : "manual";
}

function getDashboardSession(req) {
  if (AUTH_MODE !== "cloudflare_access") {
    return {
      authMode: AUTH_MODE,
      authenticated: false,
      user: "",
      role: "",
      email: "",
      source: "manual",
      salesUsers: SALES_USERS,
    };
  }

  const identity = getCloudflareAccessIdentity(req);
  const email = normalizeEmail(identity.email);
  const mapped = mapEmailToDashboardUser(email);
  return {
    authMode: AUTH_MODE,
    authenticated: Boolean(email && mapped),
    user: mapped?.user || "",
    role: mapped?.role || "",
    email,
    source: identity.source,
    reason: email ? (mapped ? "" : "Email is verified by Cloudflare Access but not mapped to a dashboard user.") : "No Cloudflare Access email found.",
    salesUsers: SALES_USERS,
  };
}

function getCloudflareAccessIdentity(req) {
  const token = text(req.headers["cf-access-jwt-assertion"]);
  const tokenPayload = decodeJwtPayload(token);
  if (tokenPayload?.email) return { email: tokenPayload.email, source: "cf-access-jwt-assertion" };

  const headerEmail = text(req.headers["cf-access-authenticated-user-email"]);
  if (headerEmail) return { email: headerEmail, source: "cf-access-authenticated-user-email" };

  return { email: "", source: "" };
}

function decodeJwtPayload(token) {
  const parts = text(token).split(".");
  if (parts.length < 2) return null;
  try {
    const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
    return JSON.parse(Buffer.from(padded, "base64").toString("utf8"));
  } catch (error) {
    return null;
  }
}

function mapEmailToDashboardUser(email) {
  const normalized = normalizeEmail(email);
  if (!normalized) return null;
  if (ADMIN_EMAILS.has(normalized)) return { user: "Admin", role: "admin" };
  const salesUser = SALES_EMAIL_MAP.get(normalized);
  if (salesUser && SALES_USERS.includes(salesUser)) return { user: salesUser, role: "sales" };
  return null;
}

function parseEmailSet(value) {
  return new Set(
    splitConfigList(value)
      .map((email) => normalizeEmail(email))
      .filter(Boolean),
  );
}

function parseSalesEmailMap(value) {
  const map = new Map();
  const raw = text(value);
  if (!raw) return map;

  if (raw.startsWith("{")) {
    try {
      const parsed = JSON.parse(raw);
      for (const [email, salesUser] of Object.entries(parsed || {})) {
        const normalizedEmail = normalizeEmail(email);
        const normalizedSales = text(salesUser);
        if (normalizedEmail && normalizedSales) map.set(normalizedEmail, normalizedSales);
      }
      return map;
    } catch (error) {
      return map;
    }
  }

  for (const pair of splitConfigList(raw)) {
    const separator = pair.includes("=") ? "=" : ":";
    const [email, salesUser] = pair.split(separator).map(text);
    const normalizedEmail = normalizeEmail(email);
    if (normalizedEmail && salesUser) map.set(normalizedEmail, salesUser);
  }
  return map;
}

function splitConfigList(value) {
  return text(value)
    .split(/[;,\n]+/)
    .map(text)
    .filter(Boolean);
}

function number(value) {
  const parsed = Number(String(value ?? "").replace(/[$,]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function text(value) {
  return String(value ?? "").trim();
}

function serveStatic(pathname, res) {
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.normalize(path.join(PUBLIC_DIR, safePath));
  if (!filePath.startsWith(PUBLIC_DIR)) return sendText(res, 403, "Forbidden");
  fs.readFile(filePath, (error, data) => {
    if (error) return sendText(res, 404, "Not found");
    res.writeHead(200, { "Content-Type": contentType(filePath) });
    res.end(data);
  });
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function sendText(res, status, textValue) {
  res.writeHead(status, { "Content-Type": "text/plain; charset=utf-8" });
  res.end(textValue);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > 1024 * 1024) {
        reject(new Error("Request body is too large."));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

function contentType(filePath) {
  return (
    {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".svg": "image/svg+xml",
    }[path.extname(filePath).toLowerCase()] || "application/octet-stream"
  );
}

function loadEnv(filePath) {
  if (!fs.existsSync(filePath)) return;
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index === -1) continue;
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim().replace(/^["']|["']$/g, "");
    if (!process.env[key]) process.env[key] = value;
  }
}
